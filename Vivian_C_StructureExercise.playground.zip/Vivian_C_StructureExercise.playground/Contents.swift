import Cocoa

var greeting = "Hello, playground"

struct EngineTypes{
    var V4 = "V-4, which gets excellent fuel economy and is great for local driving."
    var V6 = "V-6, which is less expensive to build and delivers more power."
    var V8 = "V-8, which create a lot of horsepower and is better for towing or hauling."
}

var myEngineTypes = EngineTypes()

print("I think I'll choose the \(myEngineTypes.V4) I only need this car to drive to and from work!")
print("I think I'll choose the \(myEngineTypes.V6) I need this car to have more power in case I'm in a hurry!")
print("I think I'll choose the \(myEngineTypes.V8). I'm planning on helping my friends move a lot!")
